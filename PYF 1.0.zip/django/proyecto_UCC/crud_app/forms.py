from django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'content', 'photo']

    def __init__(self, *args, **kwargs):
        super(PostForm, self).__init__(*args, **kwargs)
        self.fields['title'].widget.attrs.update({'placeholder': 'Título de la publicación'})
        self.fields['content'].widget.attrs.update({'placeholder': 'Descripción de la publicación'})
        self.fields['photo'].widget.attrs.update({'class': 'image-upload'})

    # Ejemplo de validación personalizada
    def clean_content(self):
        content = self.cleaned_data.get('content')
        if not content:
            raise forms.ValidationError("El contenido no puede estar vacío.")
        return content

