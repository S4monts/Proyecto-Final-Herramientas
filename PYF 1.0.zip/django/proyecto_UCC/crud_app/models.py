from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission,User

class CustomUser(AbstractUser):
    bio = models.TextField(blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)

    groups = models.ManyToManyField(Group, related_name='customuser_set', blank=True)
    user_permissions = models.ManyToManyField(Permission, related_name='customuser_set', blank=True)

    def __str__(self):
        return self.username



class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()  # Esto reemplaza 'description'
    photo = models.ImageField(upload_to='posts/', blank=True, null=True)  # Esto reemplaza 'image'

    def __str__(self):
        return self.title