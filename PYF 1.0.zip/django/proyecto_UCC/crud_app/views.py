from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Post
from .forms import PostForm
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages


def index(request):
    return render(request, 'crud_app/index.html')  



# Vista de registro
def user_register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        cpassword = request.POST['cpassword']
        email = request.POST['email']

        if password == cpassword:
            if User.objects.filter(username=username).exists():
                messages.error(request, 'El usuario ya existe')
            elif User.objects.filter(email=email).exists():
                messages.error(request, 'El correo ya está registrado')
            else:
                user = User.objects.create_user(username=username, password=password, email=email)
                user.save()
                messages.success(request, 'Cuenta registrada exitosamente')
                return redirect('user_login')
        else:
            messages.error(request, 'Las contraseñas no coinciden')
    
    return render(request, 'crud_app/user_register.html')

# Vista de login
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/')  # Redirige a la página de inicio o dashboard
        else:
            messages.error(request, 'Credenciales incorrectas')
    return render(request, 'crud_app/user_login.html')


# Vista de logout
def user_logout(request):
    logout(request)
    return redirect('index')  # 'index' debe estar definido en urlpatterns

# Vista para listar publicaciones
def publicacion(request):
    posts = Post.objects.all()
    return render(request, 'crud_app/publicacion.html', {'posts': posts})
def explorar(request):
    """Vista para explorar todas las publicaciones"""
    posts = Post.objects.all()  # Obtén todas las publicaciones
    return render(request, 'crud_app/explorar.html', {'posts': posts})

@login_required
def crear(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user  # Asignar el usuario autenticado
            post.save()
            return redirect('publicacion')  # Redirige a la vista de publicaciones después de guardar el post
    else:
        form = PostForm()
    return render(request, 'crud_app/crear.html', {'form': form})



# Vista para editar una publicación existente
def editar(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == "POST":
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return redirect('publicacion')
    else:
        form = PostForm(instance=post)
    return render(request, 'crud_app/editar.html', {'form': form})

# Vista para eliminar una publicación
@login_required
def eliminar(request, pk):
    post = get_object_or_404(Post, pk=pk)

    # Verificar si el usuario es el propietario del post
    if post.user != request.user:
        messages.error(request, "No tienes permiso para eliminar esta publicación.")
        return redirect('publicacion')  # Redirigir a la vista de publicaciones

    if request.method == "POST":
        post.delete()
        messages.success(request, "La publicación ha sido eliminada exitosamente.")
        return redirect('publicacion')  # Redirigir a la vista de publicaciones después de eliminar

    return render(request, 'crud_app/eliminar.html', {'post': post})