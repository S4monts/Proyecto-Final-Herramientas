
from django.urls import path
from .views import index, user_login, user_register, publicacion, crear, editar, eliminar, explorar, user_logout

urlpatterns = [
    path('', index, name='index'),
    path('login/', user_login, name='user_login'),
    path('register/', user_register, name='user_register'),  
    path('publicacion/', publicacion, name='publicacion'),
    path('crear/', crear, name='crear'),
    path('editar/<int:pk>/', editar, name='editar'),
    path('eliminar/<int:pk>/', eliminar, name='eliminar'),
    path('explorar/', explorar, name='explorar'),  
     path('logout/', user_logout, name='logout'),
]
