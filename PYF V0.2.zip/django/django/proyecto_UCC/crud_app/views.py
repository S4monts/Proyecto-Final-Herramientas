from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from .models import Post
from .forms import PostForm  

def index(request):
    return render(request, 'crud_app/index.html')  

def user_login(request):
    """Maneja el inicio de sesión del usuario."""
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('publicacion')  
    else:
        form = AuthenticationForm()
    
    return render(request, 'crud_app/user_login.html', {'form': form})  
from django.contrib.auth import logout

def user_logout(request):
    logout(request)
    return redirect('index')
    
def user_register(request):
    """Maneja el registro del usuario."""
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user_login')  
    else:
        form = UserCreationForm()
    
    return render(request, 'crud_app/user_register.html', {'form': form, 'register': True})

# Vista para listar publicaciones
def publicacion(request):
    posts = Post.objects.all()
    return render(request, 'crud_app/publicacion.html', {'posts': posts})
def explorar(request):
    """Vista para explorar todas las publicaciones"""
    posts = Post.objects.all()  # Obtén todas las publicaciones
    return render(request, 'crud_app/explorar.html', {'posts': posts})

@login_required
def crear(request):
    if request.method == "POST":
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user  # Asigna el usuario actual
            post.save()
            return redirect('publicacion')
    else:
        form = PostForm()
    return render(request, 'crud_app/crear.html', {'form': form})

# Vista para editar una publicación existente
def editar(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == "POST":
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return redirect('publicacion')
    else:
        form = PostForm(instance=post)
    return render(request, 'crud_app/editar.html', {'form': form})

# Vista para eliminar una publicación
@login_required
def eliminar(request, pk):
    post = get_object_or_404(Post, pk=pk)

    # Verificar si el usuario es el propietario del post
    if post.user != request.user:
        messages.error(request, "No tienes permiso para eliminar esta publicación.")
        return redirect('publicacion')  # Redirigir a la vista de publicaciones

    if request.method == "POST":
        post.delete()
        messages.success(request, "La publicación ha sido eliminada exitosamente.")
        return redirect('publicacion')  # Redirigir a la vista de publicaciones después de eliminar

    return render(request, 'crud_app/eliminar.html', {'post': post})