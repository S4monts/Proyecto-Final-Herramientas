
from django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'description', 'image']

    def __init__(self, *args, **kwargs):
        super(PostForm, self).__init__(*args, **kwargs)
        self.fields['title'].widget.attrs.update({'placeholder': 'Título de la publicación'})
        self.fields['description'].widget.attrs.update({'placeholder': 'Descripción de la publicación'})
        self.fields['image'].widget.attrs.update({'class': 'image-upload'})

    # Ejemplo de validación personalizada
    def clean_title(self):
        title = self.cleaned_data.get('title')
        if not title:
            raise forms.ValidationError("El título es obligatorio.")
        return title
