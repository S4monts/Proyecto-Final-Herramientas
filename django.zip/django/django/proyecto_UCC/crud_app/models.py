from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission  # Asegúrate de importar lo necesario

class CustomUser(AbstractUser):
    bio = models.TextField(blank=True, null=True)  # Biografía opcional del usuario
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)  # Foto de perfil opcional

    groups = models.ManyToManyField(Group, related_name='customuser_set', blank=True)  # Cambiar el related_name
    user_permissions = models.ManyToManyField(Permission, related_name='customuser_set', blank=True)  # Cambiar el related_name

    def __str__(self):
        return self.username  # Muestra el nombre de usuario como representación del usuario

class Post(models.Model):
    title = models.CharField(max_length=100)  # Título de la publicación
    description = models.TextField()  # Descripción de la imagen
    image = models.ImageField(upload_to='posts/')  # Imagen que sube el usuario, almacenada en 'posts'
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)  # Relación con el usuario que subió la imagen
    created_at = models.DateTimeField(auto_now_add=True)  # Fecha de creación automática

    def __str__(self):
        return self.title
